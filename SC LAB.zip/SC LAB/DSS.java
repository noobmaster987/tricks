import java.util.Scanner;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;


public class DSS
{
    static String PlainText;
    static String HashCode;
    static KeyPairGenerator keyPairGenerator;
    static KeyPair keyPair;
    static PrivateKey privateKey;
    static PublicKey publicKey;
     static byte[] digitalsignature;
     
    public static void GenerateKeys() throws Exception
    {
         keyPairGenerator = KeyPairGenerator.getInstance("DSA");
         keyPairGenerator.initialize(2048);
         keyPair=keyPairGenerator.generateKeyPair();
         privateKey = keyPair.getPrivate();
         publicKey = keyPair.getPublic();
    }
    
     public static void DigitalSignature(String PlainText,PrivateKey privateKey) throws Exception
     {
         byte[] input=PlainText.getBytes();
          Signature signature= Signature.getInstance("SHA256withDSA");
        signature.initSign(privateKey);
        signature.update(input);
         digitalsignature=signature.sign();
     }
    public static boolean DigitalSignatureVerify(String PlainText,byte[] digitalsignature,PublicKey publicKey) throws Exception
    {
        byte[] input=PlainText.getBytes();
        Signature signature= Signature.getInstance("SHA256withDSA");
        signature.initVerify(publicKey);
        signature.update(input);
        return signature.verify(digitalsignature);
    }
    
	public static void main(String[] args) throws Exception
	{
	    Scanner In=new Scanner(System.in);
		System.out.println("Enter The PlainText : ");
		PlainText=In.nextLine();
		GenerateKeys();
		DigitalSignature(PlainText,privateKey);
		boolean verify=DigitalSignatureVerify(PlainText,digitalsignature,publicKey);
		System.out.println("PlainText          : "+PlainText);
		System.out.println("Digital Signature  : "+new String(digitalsignature,"UTF8"));
		if(verify)
		    System.out.println("Digital Signature verified successfully");
		else
		    System.out.println("Digital Signature verification failed");
	}
}

// PlainText and Keyword in capital but white space allowed (not in keyword only in plaintext)

import java.util.Scanner;

class VigenereCipher
{
	static String PlainText;
	static String KeyWord;
	static StringBuffer Key = new StringBuffer();
	static StringBuffer EncryptedText = new StringBuffer();
	static StringBuffer DecryptedText = new StringBuffer();	
	public static void GenerateKey(String KeyWord)
	{
		for(int i=0;i<PlainText.length();i++)
		{
				Key.append(KeyWord.charAt(i%KeyWord.length()));
		}
	}
	public static void Encrypt(String PlainText, StringBuffer Key)
	{
		int temp=0;
		for (int i = 0; i < PlainText.length(); i++)
		{
			if (PlainText.charAt(i)==' ')
				EncryptedText.append(' ');
			else
			{
				temp = (PlainText.charAt(i) + Key.charAt(i)) %26;
				temp += 'A'; //65
				EncryptedText.append((char)temp);
			}
		}
	}
	public static void Decrypt(StringBuffer EncryptedText, StringBuffer Key)
	{
		int temp=0;
		for (int i = 0; i < EncryptedText.length(); i++)
		{
			if (EncryptedText.charAt(i)==' ')
				DecryptedText.append(' ');
			else
			{
					temp = (EncryptedText.charAt(i) - Key.charAt(i) + 26) %26;
					temp += 'A'; //65
					DecryptedText.append((char)temp);
			}
			
		}
	}
	public static void main(String args[])
	{
		Scanner In = new Scanner(System.in);
		System.out.println(" Enter The PlainText : ");
		PlainText = In.nextLine();
		System.out.println(" Enter The KeyWord: ");
		KeyWord = In.nextLine();
		GenerateKey(KeyWord);
		Encrypt(PlainText,Key);
		Decrypt(EncryptedText,Key);
		System.out.println(" PlainText   	: " + PlainText);
		System.out.println(" Key        	: " + Key);
		System.out.println(" Encrpyted Text : " + EncryptedText);
		System.out.println(" Decrypted Text : " + DecryptedText);
	}
}




/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
/*
import java.util.Scanner;

public class Main
{
    static String PlainText;
static String KeyWord;
static StringBuffer Key = new StringBuffer();
static StringBuffer EncryptedText = new StringBuffer();
static StringBuffer DecryptedText = new StringBuffer();	

public static void GenerateKey(String KeyWord)
{
for(int i=0;i<PlainText.length();i++)
    {
        Key.append(KeyWord.charAt(i%KeyWord.length()));
    }
}
public static void Encrypt(String PlainText, StringBuffer Key)
{
    int KeyVal=0,temp=0;
       for (int i = 0; i < PlainText.length(); i++)
    {
		if (PlainText.charAt(i)==' ')
			EncryptedText.append(' ');
		else
		{
			if (PlainText.charAt(i)>='A' && PlainText.charAt(i)<='Z')
			{
				if(Key.charAt(i)>='A' && Key.charAt(i)<='Z')
				    KeyVal=(int)Key.charAt(i);
				else if(Key.charAt(i)>='a' && Key.charAt(i)<='z')
					KeyVal=(int)Key.charAt(i)-32;
				temp = (PlainText.charAt(i) + KeyVal) %26;
                temp += 'A'; //65
			}
			else if (PlainText.charAt(i)>='a' && PlainText.charAt(i)<='a')
			{
				if(Key.charAt(i)>='a' && Key.charAt(i)<='z')
					KeyVal=(int)Key.charAt(i);
				else if(Key.charAt(i)>='A' && Key.charAt(i)<='Z')
					KeyVal=(int)Key.charAt(i)+32;
				temp = (PlainText.charAt(i) + KeyVal) %26;
        temp += 'a'; //65
			}
 
        EncryptedText.append((char)temp);
		}
    }
}
public static void Decrypt(StringBuffer EncryptedText, StringBuffer Key)
{
    int KeyVal=0,temp=0;
        
       for (int i = 0; i < EncryptedText.length(); i++)
    {
		if (EncryptedText.charAt(i)==' ')
			DecryptedText.append(' ');
		else
		{
			if (EncryptedText.charAt(i)>='A' && EncryptedText.charAt(i)<='Z')
			{
				if(Key.charAt(i)>='A' && Key.charAt(i)<='Z')
					KeyVal=(int)Key.charAt(i);
				else if(Key.charAt(i)>='a' && Key.charAt(i)<='z')
					KeyVal=(int)Key.charAt(i)-32;
			    temp = (EncryptedText.charAt(i) - KeyVal + 26) %26;
				temp += 'A'; //65
			}
			else if (EncryptedText.charAt(i)>='a' && EncryptedText.charAt(i)<='a')
			{
				if(Key.charAt(i)>='a' && Key.charAt(i)<='z')
					KeyVal=(int)Key.charAt(i);
				else if(Key.charAt(i)>='A' && Key.charAt(i)<='Z')
					KeyVal=(int)Key.charAt(i)+32;
				temp = (EncryptedText.charAt(i) - KeyVal + 26) %26;
				temp += 'a'; //65
			}
			
 
        DecryptedText.append((char)temp);
		}
        
    }
}

public static void main(String args[])
{
Scanner In = new Scanner(System.in);
System.out.println(" Enter The PlainText : ");
PlainText = In.nextLine();
System.out.println(" Enter The KeyWord: ");
KeyWord = In.nextLine();
GenerateKey(KeyWord);
Encrypt(PlainText,Key);
Decrypt(EncryptedText,Key);
System.out.println(" PlainText   	: " + PlainText);
System.out.println(" Key        	: " + Key);
System.out.println(" Encrpyted Text : " + EncryptedText);
System.out.println(" Decrypted Text : " + DecryptedText);
}
}
*/
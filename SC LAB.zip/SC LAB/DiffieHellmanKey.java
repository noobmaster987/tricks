
 import java.util.Scanner;

 
public class DiffieHellmanKey 
{
  
static int p;
  
static int q;
  
static int XA;
  
static int XB;
  
static int YA;
  
static int YB;
  
static int KA;
  
static int KB;
  
 
public static void DiffieHellmanKey (int p, int q, int XA, int XB) 
  {
    
YA = (int) ((Math.pow (q, XA)) % p);
    
YB = (int) ((Math.pow (q, XB)) % p);
    
KA = (int) ((Math.pow (YB, XA)) % p);
    
KB = (int) ((Math.pow (YA, XB)) % p);
  
} 
 
public static void main (String[]args) 
  {
    
Scanner In = new Scanner (System.in);
    
System.out.println ("Enter The Prime Number : ");
    
p = In.nextInt ();
    
System.out.println ("Enter The Primitive Root : ");
    
q = In.nextInt ();
    
System.out.println ("Enter The A's Private value : ");
    
XA = In.nextInt ();
    
System.out.println ("Enter The B's Private value : ");
    
XB = In.nextInt ();
    
DiffieHellmanKey (p, q, XA, XB);
    
System.out.println ("Prime Number      : " + p);
    
System.out.println ("Primitive Root    : " + q);
    
System.out.println ("A's Private value : " + XA);
    
System.out.println ("B's Private value : " + XB);
    
System.out.println ("A's Public Key    : " + YA);
    
System.out.println ("B's Public Key     : " + YB);
    
System.out.println ("A's Shared Key     : " + KA);
    
System.out.println ("B's Shared Key     : " + KB);
    
if (KA == KB)
      
System.out.println ("Key Shared Successfully and The Shared Key is " +
			   KA);
    
    else
      
System.out.println ("Ooops...Something went wrong");
  
 
}

}



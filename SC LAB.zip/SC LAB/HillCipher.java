//Provide inverse key matrix . No space allowed . Plaintext must be a multiple of 3 . Key matrix 3*3

import java.util.Scanner;

class HillCipher
{
	static String PlainText;
	static String Key;
	static int KeyMatrix[][]=new int[3][3];
	static String InverseKey;
	static int InverseKeyMatrix[][]=new int[3][3];
	static int PlainTextMatrix[][]=new int[3][1];
	static int CipherTextMatrix[][]=new int[3][1];
	static StringBuffer EncryptedText = new StringBuffer();
	static StringBuffer DecryptedText = new StringBuffer();	
	public static void GenerateKeyMatrix(String Key)
	{
		int k = 0;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            KeyMatrix[i][j] = (int)Key.charAt(k) - 65;
            k++;
        }
    }
	}
	public static void GenerateInverseKeyMatrix(String InverseKey)
	{
		int k = 0;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            InverseKeyMatrix[i][j] = (int)InverseKey.charAt(k) - 65;
            k++;
        }
    }
	}
	public static void Encrypt(int KeyMatrix[][],int i,String PlainText)
	{
		GeneratePlainTextMatrix(PlainText,i);
		int x, y, z;
    for (y = 0; y < 3; y++)
    {
        for (z = 0; z < 1; z++)
        {
            CipherTextMatrix[y][z] = 0;
         
            for (x = 0; x < 3; x++)
            {
                CipherTextMatrix[y][z] += KeyMatrix[y][x] * PlainTextMatrix[x][z];
            }
			CipherTextMatrix[y][z] = CipherTextMatrix[y][z] % 26;
		}
	}
		for (y = 0; y < 3; y++)
		{
        for (z = 0; z < 1; z++)
        {
			EncryptedText.append((char)(CipherTextMatrix[y][z]+65));
		}
	}
	}
		public static void GeneratePlainTextMatrix(String PlainText,int Start)
	{
		int k = Start;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 1; j++)
        {
            PlainTextMatrix[i][j] = (int)PlainText.charAt(k) - 65;
            k++;
        }
    }
	}	
	
	public static void Decrypt(int InverseKeyMatrix[][],int start,StringBuffer EncryptedText)
	{
		GenerateCipherTextMatrix(EncryptedText,start);
		int x, i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            PlainTextMatrix[i][j] = 0;
         
            for (x = 0; x < 3; x++)
            {
                  PlainTextMatrix[i][j] += InverseKeyMatrix[i][x] * CipherTextMatrix[x][j];
            }
			PlainTextMatrix[i][j] = PlainTextMatrix[i][j] % 26;
		}
	}
		for (i = 0; i < 3; i++)
		{
        for (j = 0; j < 1; j++)
        {
			DecryptedText.append((char)(PlainTextMatrix[i][j]+65));
		}
	}
	}

	public static void GenerateCipherTextMatrix(StringBuffer EncryptedText,int start)
	{
		int k = start;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 1; j++)
        {
            CipherTextMatrix[i][j] = (int)EncryptedText.charAt(k) - 65;
            k++;
        }
    }
	}
	
	public static void main(String args[])
	{
		Scanner In = new Scanner(System.in);
		System.out.println(" Enter The PlainText : ");
		PlainText = In.nextLine();
		System.out.println(" Enter The Key: ");
		Key = In.nextLine();
		GenerateKeyMatrix(Key);
		for(int i=0;i<PlainText.length();i=i+3)
			Encrypt(KeyMatrix,i,PlainText);
		System.out.println(" Enter The inverse Key : ");
		InverseKey=In.nextLine();
		GenerateInverseKeyMatrix(InverseKey);
		for(int i=0;i<PlainText.length();i=i+3)
			Decrypt(InverseKeyMatrix,i,EncryptedText);
		
		System.out.println(" PlainText   	: " + PlainText);
		System.out.println(" Key        	: " + Key);
		System.out.println(" Inverse Key    : " + InverseKey);
		System.out.println(" Encrpyted Text : " + EncryptedText);
		System.out.println(" Decrypted Text : " + DecryptedText);
	}
}


import java.util.Scanner;
import javax.crypto.KeyGenerator;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import java.util.Base64;

public class AES
{
        static String PlainText;
    static String EncryptedText;
    static String DecryptedText;
     static byte[] EncryptedTextBytes;
    
    public static void encrypt(String PlainText,SecretKey secretkey)
    {
        try 
        {
            Cipher Encrypt=Cipher.getInstance("AES/ECB//PKCS5Padding");
        Encrypt.init(Cipher.ENCRYPT_MODE, secretkey);
        byte[] PlainTextBytes=PlainText.getBytes("UTF-8");
        EncryptedTextBytes=Encrypt.doFinal(PlainTextBytes);
        EncryptedText=Base64.getEncoder().encodeToString(EncryptedTextBytes);
         } 
        catch(Exception e) 
        {
          e.printStackTrace();
  
        }
        
    }
    
     public static void decrypt(byte[] EncryptedTextBytes,SecretKey secretkey)
    {
        try {
             Cipher Decrypt=Cipher.getInstance("AES/ECB//PKCS5Padding");
        Decrypt.init(Cipher.DECRYPT_MODE, secretkey);
        byte[] DecryptedTextBytes=Decrypt.doFinal(EncryptedTextBytes);
        DecryptedText=new String(DecryptedTextBytes);
            
        } 
        catch(Exception e) 
        {
            e.printStackTrace();

        }
        
    }
	public static void main(String[] args) 
	{
	    try {
	        Scanner In = new Scanner(System.in);
		System.out.println("Enter The PlainText : ");
		PlainText = In.nextLine();
		KeyGenerator keygenerator = KeyGenerator.getInstance("AES");
		SecretKey secretkey = keygenerator.generateKey();
		encrypt(PlainText,secretkey);
		decrypt(EncryptedTextBytes,secretkey);
		System.out.println("PlainText      : "+PlainText);
		System.out.println("SecretKey      : "+secretkey);
		System.out.println("Encrypted Text : "+EncryptedText);
		System.out.println("Decrypted Text : "+DecryptedText);
	        
	    } catch(Exception e)
	    {
	        e.printStackTrace();

	    }
	    
		
	}
}


import java.util.Scanner;

class RailFenceCipher
{
	boolean move_down=false;
		int col=PlainText.length(),row=Depth,row1=0,col1=0;
		EncrpytMatrix = new char[row][col];
		for (int i=0; i < row; i++)
		{
        for (int j = 0; j < col; j++)
		{
            EncrpytMatrix[i][j] = '*';
		}
		}
		for (int i=0; i < PlainText.length(); i++)
    {
        if (row1 == 0 || row1 == Depth-1)
            move_down = !move_down;
        EncrpytMatrix[row1][col1++] = PlainText.charAt(i);
        if(move_down)
            row1++;
        else 
            row1--;
    }
	for (int i=0; i < row; i++)
        for (int j=0; j < col; j++)
            if (EncrpytMatrix[i][j]!='*')
                EncryptedText.append(EncrpytMatrix[i][j]);
	}
	
	public static void Decrypt(StringBuffer EncryptedText,int Depth)
	{
		boolean move_down=false;
		int col=EncryptedText.length(),row=Depth,row1=0,col1=0,row2=0,col2=0;
		DecrpytMatrix = new char[row][col];
		for (int i=0; i < row; i++)
		{
        for (int j = 0; j < col; j++)
		{
            DecrpytMatrix[i][j] = '*';
		}
		}
		for (int i=0; i < EncryptedText.length(); i++)
    {
        if (row1 == 0 || row1 == Depth-1)
            move_down = !move_down;
        DecrpytMatrix[row1][col1++] = '#';
        if(move_down)
            row1++;
        else 
            row1--;
    }
	int k = 0;
    for (int i=0; i< row; i++)
        for (int j=0; j< col; j++)
            if (DecrpytMatrix[i][j] == '#' && k <EncryptedText.length())
			{
                DecrpytMatrix[i][j] = EncryptedText.charAt(k);
				k++;
			}
			move_down=false;
		for (int i=0; i< EncryptedText.length(); i++)
    {
		if (row2 == 0 || row2 == Depth-1)
            move_down = !move_down;
        if (DecrpytMatrix[row2][col2] != '*')
            DecryptedText.append(DecrpytMatrix[row2][col2++]);
        if(move_down)
            row2++;
        else 
            row2--;
    }	
	}
	public static void main(String args[])
	{
		Scanner In = new Scanner(System.in);
		System.out.println(" Enter The PlainText : ");
		PlainText = In.nextLine();
		System.out.println(" Enter The Depth: ");
		Depth = In.nextInt();
		Encrypt(PlainText,Depth);
		Decrypt(EncryptedText,Depth);
		
		System.out.println(" PlainText   	: " + PlainText);
		System.out.println(" Depth       	: " + Depth);
		System.out.println(" Encrpyted Text : " + EncryptedText);
		System.out.println(" Decrypted Text : " + DecryptedText);
	}
}

// Note : key must be in caps and must be of unique letters

import java.util.Scanner;
import java.util.*;

public class Main 
{
    static String PlainText;
    static String Key;
    static  Map<Integer,Integer> KeyMap = new HashMap<Integer,Integer>();
    static char EncryptMatrix[][];
	 static char DecryptMatrix[][];
	static StringBuffer EncryptedText=new StringBuffer();
	static StringBuffer DecryptedText=new StringBuffer();
    public static void SetPermutationOrder()
    {
        for(int i=0;i<Key.length();i++)
        {
            KeyMap.put(((int)Key.charAt(i))-65,i);
        }
    }
    public static void Encrypt(String PlainText,String Key) throws Exception
    {
        int row,col;
        col=Key.length();
        row=PlainText.length()/col;
        int rem=PlainText.length()%col;
        if(rem!=0)
            row++;
		EncryptMatrix=new char[row][col];
	for (int i=0,k=0; i < row; i++)
    {
        for (int j=0; j<col; )
        {
            if(PlainText.charAt(k) == '\0')
            {
                EncryptMatrix[i][j] = '_'; 
                j++;
            }
              
            if( Character.isAlphabetic(PlainText.charAt(k)) || PlainText.charAt(k)==' ')
            { 
                EncryptMatrix[i][j] = PlainText.charAt(k);
                j++;
            }
            k++;
        }
    }
	Iterator<Map.Entry<Integer,Integer>> itr = KeyMap.entrySet().iterator();
	int j;
	while(itr.hasNext())
	{
		 Map.Entry<Integer,Integer> entry = itr.next();
		j=entry.getValue();
		for (int i=0; i<row; i++)
        {
                 if( Character.isAlphabetic(EncryptMatrix[i][j]) || EncryptMatrix[i][j]==' ' || EncryptMatrix[i][j]=='_')
                EncryptedText.append(EncryptMatrix[i][j]);
        }
    }
	}
	public static void Decrypt(StringBuffer EncryptedText,String Key) throws Exception
    {
        int col=Key.length();
        int row=EncryptedText.length()/col;
        char CipherTextMatrix[][]=new char[row][col];
        for(int j=0,k=0;j<col;j++)
        for(int i=0;i<row;i++)
        CipherTextMatrix[i][j]=EncryptedText.charAt(k++);
        
        int index=0;
        
        	Iterator<Map.Entry<Integer,Integer>> itr = KeyMap.entrySet().iterator();
	while(itr.hasNext())
	{
		 Map.Entry<Integer,Integer> entry = itr.next();
		 KeyMap.replace(entry.getKey(),index++);
	}
	
	char DecryptMatrix[][]=new char[row][col];
//	Iterator<Map.Entry<Integer,Integer>> itr1 = KeyMap.entrySet().iterator();
	int k = 0;
    for (int l=0,j; Key.charAt(l)!='\0'; k++,l++)
    {
        j = KeyMap.get(((int)Key.charAt(l))-65);
        for (int i=0; i<row; i++)
        {
            DecryptMatrix[i][k]=CipherTextMatrix[i][j];
        }
    }
    
    for (int i=0; i<row; i++)
    {
        for(int j=0; j<col; j++)
        {
            if(DecryptMatrix[i][j] != '_')
                DecryptedText.append(DecryptMatrix[i][j]);
        }
    }
    }
	public static void main(String[] args) throws Exception
	{
	    Scanner In=new Scanner(System.in);
		System.out.println("Enter the PlainText : ");
		PlainText= In.nextLine();
		System.out.println("Enter the Key : ");
		Key= In.nextLine();
		SetPermutationOrder();
		Encrypt(PlainText,Key);
		Decrypt(EncryptedText,Key);
		System.out.println(" PlainText : "+ PlainText);
		System.out.println(" Key : "+ Key);
		System.out.println(" Encrypted Text : "+ EncryptedText);
	}
}



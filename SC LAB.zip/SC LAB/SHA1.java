import java.util.Scanner;
import java.security.MessageDigest;


public class SHA1
{
    static String PlainText;
    static String HashCode;
    
    public static void SHA1(String PlainText)
    {
        try 
        {
            MessageDigest md = MessageDigest.getInstance("SHA1");
        md.update(PlainText.getBytes());
        byte[] output = md.digest();
        HashCode = bytesToHex(output);
            
        } catch(Exception e) 
        {
            System.out.println("Exception : "+e);
        }
    }
    
    public static String bytesToHex(byte[] bytes) {
 char hexDigit[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
 StringBuffer buff = new StringBuffer();
 for (byte b : bytes) {
 buff.append(hexDigit[(b >> 4) & 0x0f]);
 buff.append(hexDigit[b & 0x0f]);
 }
 return buff.toString();
 }

    
	public static void main(String[] args) 
	{
	    Scanner In=new Scanner(System.in);
		System.out.println("Enter The PlainText : ");
		PlainText=In.nextLine();
		SHA1(PlainText);
		System.out.println("PlainText : "+PlainText);
		System.out.println("HashCode  : "+HashCode);
	}
}

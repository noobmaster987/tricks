import java.util.Scanner;

class CaesarCipher
{
	static String PlainText;
	static int Shift;
	static StringBuffer EncryptedText = new StringBuffer();
	static StringBuffer DecryptedText = new StringBuffer();	
	public static void Encrypt(String PlainText, int shift)
	{
		for (int i=0; i<PlainText.length(); i++)
		{
			if(PlainText.charAt(i)==' ')
				EncryptedText.append(' ');
			else
			{
				if (Character.isUpperCase(PlainText.charAt(i)))
				{
					char ch = (char)(((int)PlainText.charAt(i) + shift - 65) % 26 + 65);
					EncryptedText.append(ch);
				}
				else
				{
					char ch = (char)(((int)PlainText.charAt(i) + shift - 97) % 26 + 97);
					EncryptedText.append(ch);
				}
			}
		}
	}
	public static void Decrypt(StringBuffer EncryptedText, int shift)
	{
		for (int i=0; i<EncryptedText.length(); i++)
		{
			if(EncryptedText.charAt(i)==' ')
				DecryptedText.append(' ');
			else
			{
				if (Character.isUpperCase(EncryptedText.charAt(i)))
				{
					char ch = (char)(((int)EncryptedText.charAt(i) + shift - 65) % 26 + 65);
					DecryptedText.append(ch);
				}
				else
				{
					char ch = (char)(((int)EncryptedText.charAt(i) + shift - 97) % 26 + 97);
					DecryptedText.append(ch);
				}
			}
		}
	}
	public static void main(String args[])
	{
		Scanner In = new Scanner(System.in);
		System.out.println(" Enter The PlainText : ");
		PlainText = In.nextLine();
		System.out.println(" Enter The Shift Value : ");
		Shift = In.nextInt();
		//FillWhiteSpaces(PlainText);
		Encrypt(PlainText,Shift);
		Decrypt(EncryptedText,26-Shift);
		System.out.println(" PlainText   	: " + PlainText);
		System.out.println(" Shift Value 	: " + Shift);
		System.out.println(" Encrpyted Text : " + EncryptedText);
		System.out.println(" Decrypted Text : " + DecryptedText);
	}
}